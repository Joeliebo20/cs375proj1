#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include "Card.h"

using namespace std;

Card::Card() {

}

Card::Card(string cardName, string amount){
    card = cardName;
    price = amount;
}

Card::Card(string cardName, string amount, string totes, string amt) {
    card = cardName;
    price = amount;
    total = totes;
    amtCards = amt;
}