#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include "Card.h"
#include <algorithm>
#include <math.h>
#include <time.h>
#include <bits/stdc++.h>

using namespace std;

struct subset {
    vector<Card> cards;
    int total;
};

vector<Card> parsePrice(string priceFile){
    ifstream f;
    f.open(priceFile);
    vector<string> cards;
    vector<string> prices;
    vector<Card> priceCards;
    vector<Card> totals;
    string line;
    string numCards;
    string max;
    string price;
    string card;
    int sets = 0;
    bool go = true;
    bool juul = true;
    while(go) {
        sets++;
        f >> numCards >> max;
        go = false;
    }
    while(f >> card >> price) {
        if(card.length() <= 4) {
            sets++;
            numCards = card;
            max = price;
        }
        else {
            Card c;
            c.setCard(card);
            c.setPrice(price);
            c.setMax(max);
            c.setAmt(numCards);
            priceCards.push_back(c);
        }
        priceCards.at(0).setSets(sets);
    }
    
    /*for(int i = 0; i < priceCards.size(); i++) {
        cout << priceCards.at(i);
    } */
    //cout << endl;
    return priceCards;
}

vector<Card> parseMarket(string marketFile) {
    ifstream f;
    f.open(marketFile);
    vector<string> cards;
    vector<string> prices;
    vector<Card> marketCards;
    string line;
    string numCards;
    string max;
    string price;
    string card;
    int go = true;
    while(go) {
        f >> numCards;
        go = false;
    }
    while(f >> card >> price) {
        cards.push_back(card);
        prices.push_back(price);
    }
    for(int i = 0; i < stoi(numCards); i++) {
        Card c;
        c.setCard(cards.at(i));
        c.setPrice(prices.at(i));
        marketCards.push_back(c);
    }
    /*for(int i = 0; i < marketCards.size(); i++) {
        cout << marketCards.at(i);
    } */
    return marketCards;
}

int getIndex(vector<Card> cards, Card c) {
    int index;
    auto it = find(cards.begin(), cards.end(), c);
    if(it != cards.end()) {
        index = it - cards.begin();
    }
    else {
        index = -1;
    }
    return index;
}

struct subset computeMaxProfit(vector<Card> cards, vector<Card> marketCards, int total) {
    struct subset sub;
    int maxProfit = 0;
    int profit = 0;
    int first_weight = 0;
    sub.total = 0;
    int p = 0;
    int k = 0;
    int weight = 0;
    int current = 0;
    int setSize = cards.size();
    int index2;
    vector<Card> m;
    Card curr_card;
    for(int i = 0; i < cards.size(); i++) {
        first_weight += stoi(cards.at(i).getPrice());
    }
    //cout << first_weight;
    if(first_weight <= total) {
        int index;
        for(int i = 0; i < cards.size(); i++) {
            curr_card = cards.at(i);
            index = getIndex(marketCards, curr_card);
            if(index != -1) {
                maxProfit += stoi(marketCards.at(index).getPrice());
            }
        }
        sub.total = maxProfit - first_weight;
        sub.cards = cards;
    }
    else { 
        unsigned int powerSetSize = pow(2, setSize);
        for(int j = 0; j < powerSetSize; j++) {
            vector<Card> s;
            for(int n = 0; n < setSize; n++) {
                Card curr_card2;
                if(j & (1 << n)) {
                    s.push_back(cards.at(n));
                }
                
            }
            for(int i = 0; i < s.size(); i++) {
                weight += stoi(s.at(i).getPrice());
                Card curr_card2 = s.at(i);
                index2 = getIndex(marketCards, curr_card2);
                if(index2 != 1) {
                    profit += stoi(marketCards.at(index2).getPrice());
                }
            }
            if(weight <= total) {
                if(profit > maxProfit) {
                    maxProfit = profit;
                    m = s;
                    sub.cards = m;
                    sub.total = maxProfit - weight;
                    //s.clear();
                    //cout << "greater" << endl;
                }
            }
            profit = 0;
            weight = 0;
        }
        return sub;
    }
}

bool onMarket(Card card, vector<Card> market) {
    for(int i = 0; i < market.size(); i++) {
        int counter = 0;
        if(count(market.begin(), market.end(), card)) {
            counter++;
        }
        if(counter > 0) {return true;}
        else {return false;}
    }
   
}

int main(int argc, char *argv[]) {
    ofstream f;
    f.open("output.txt");
    time_t start, end;
    time(&start);
    string priceFile(argv[1]);
    string marketFile(argv[2]);
    vector<Card> sellerCards;
    vector<Card> marketCards;
    int counter = 0;
    string curr_card_total;
    sellerCards = parsePrice(priceFile);
    marketCards = parseMarket(marketFile);
    int i = 0;
    while(i < sellerCards.size()) {
        Card curr_card = sellerCards.at(i);
        if(!onMarket(curr_card, marketCards)) {
            cout << "Card " << curr_card << " is not on the market" << endl;
            exit(EXIT_FAILURE);
        }
        i++;
    }
    int j = 0;
    int p = 0;
    int val;
    int end_loop = 0;

    vector<Card> temp;
    struct subset x;
    string curr = sellerCards.at(0).getAmount();
    int current = 0;
    int sets = sellerCards.at(0).getSets();
    //cout << sets;
    while(p < sets) {
        while(j < stoi(curr)) {
            //cout << current << endl;
            //cout << sellerCards.at(current) << endl;
            temp.push_back(sellerCards.at(current));
            //cout << temp.at(current).getMax() << " " << temp.at(current) << endl;
            j++;
            if(current != sellerCards.size()-1) {current++;}
            else{break;}
        }
        curr = sellerCards.at(current).getAmount();
        val = stoi(sellerCards.at(current - 1).getMax());
        x = computeMaxProfit(temp, marketCards, val);
        f << "Size of input: " << temp.size() << endl;
        f << "Maximum profit: " << x.total << endl;
        for(int i = 0; i < x.cards.size(); i++) {
            f << "Cards bought: " << x.cards.at(i) << endl;
        }
        f << "---------------------------------------" << endl;
        temp.clear();
        j = 0;
        p++; 
    }  
    f << endl;
    time(&end);
    double time_taken = double(end - start);
    f << "Time taken is: " << fixed << time_taken << setprecision(5);
    f << " sec " << endl;
}