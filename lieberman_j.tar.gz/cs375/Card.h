#ifndef _Card_h
#define _Card_h

#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

class Card {
    public:
        Card();
        Card(string card, string price);
        Card(string card, string price, string total, string amtCards);
        string getCard(){return card;}
        string getPrice(){return price;}
        string getMax(){return total;}
        string getAmount(){return amtCards;}
        int getSets(){return sets;}
        void setCard(string cardName){card = cardName;}
        void setPrice(string amount){price = amount;}
        void setMax(string money){total = money;}
        void setAmt(string amt){amtCards = amt;}
        void setSets(int s){sets = s;}
        friend ostream& operator<<(ostream& os, const Card& c){
            os << c.card;
            return os;
        }
        bool operator==(const Card &c) {
            return this->card == c.card;
        }       
        bool operator!=(const Card &c) {
            return this->card != c.card;
        }
    private:
        string card;
        string price;
        string total;
        string amtCards;
        int sets;
};

#endif